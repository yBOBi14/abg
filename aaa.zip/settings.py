dict_settings = {
  "save_empty": "y",
  "threads": "666"
}
